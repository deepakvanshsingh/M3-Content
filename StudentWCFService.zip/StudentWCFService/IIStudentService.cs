﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace StudentWCFService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IIStudentService" in both code and config file together.
    [ServiceContract]
    public interface IIStudentService
    {
        [OperationContract]
        int AddStudent(Student student);
        [OperationContract]
        int UpdateStudent(Student student);
        [OperationContract]
        int Deletetudent(int id);
        [OperationContract]
        Student SearchStudent(int id);
        [OperationContract]
        List<Student> DisplayStudent();
    }
   
    [DataContract]
    public class Student
    {
        [DataMember]
        public int Id { get; set; }
        [DataMember]
        public string StudentName { get; set; }
        [DataMember]
        public int DepartmenttCode { get; set; }
        [DataMember]
        public DateTime StudentDob { get; set; }
        [DataMember]
        public string StudentAddress { get; set; }

    }
   

}
