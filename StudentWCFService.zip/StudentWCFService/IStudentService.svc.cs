﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Windows;

namespace StudentWCFService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "IStudentService" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select IStudentService.svc or IStudentService.svc.cs at the Solution Explorer and start debugging.
    public class IStudentService : IIStudentService
    {
        static string conStr = ConfigurationManager.ConnectionStrings["ConString"].ConnectionString;
        SqlConnection con = new SqlConnection(conStr);
        SqlCommand cmd = new SqlCommand();
        string query = null;
        public int AddStudent(Student student)
        {
            int recordAffected = 0;
            try
            {
                query = "Insert Into StudentService_dsingh58(StudentName,DepartmentCode,StudentDob,StudentAddress) Values(@Name,@DeptCode,@StdDob,@StdAddress)";
                cmd.Parameters.AddWithValue("@Name", student.StudentName);
                cmd.Parameters.AddWithValue("@DeptCode", student.DepartmenttCode);
                cmd.Parameters.AddWithValue("@StdDob", student.StudentDob);
                cmd.Parameters.AddWithValue("@StdAddress", student.StudentAddress);
                cmd.CommandText = query;
                cmd.Connection = con;
                if (con.State == ConnectionState.Closed)
                    con.Open();
                recordAffected = cmd.ExecuteNonQuery();

            }catch(SqlException ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
            return recordAffected;
        }

        public List<Student> DisplayStudent()
        {
           List<Student> students = new List<Student>();
            try
            {
                query = "Select * from StudentService_dsingh58";
                cmd.CommandText = query;
                cmd.Connection = con;
                if (con.State == ConnectionState.Closed)
                    con.Open();
          SqlDataReader dataReader= cmd.ExecuteReader();
                if (dataReader.HasRows)
                {
                    while (dataReader.Read())
                    {
                        Student student = new Student();
                        student.Id = int.Parse(dataReader["Id"].ToString());
                        student.StudentName = dataReader["StudentName"].ToString();
                        student.DepartmenttCode = int.Parse(dataReader["DepartmentCode"].ToString());
                        student.StudentDob = DateTime.Parse(dataReader["StudentDob"].ToString());
                        student.StudentAddress = dataReader["StudentAddress"].ToString();
                        students.Add(student);
                    }
                }

            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
            return students;

        }

        public int Deletetudent(int id)
        {
            int recordAffected = 0;
            try
            {
                query = "Delete from StudentService_dsingh58 Where Id=@studentId";
                cmd.Parameters.AddWithValue("@studentId", id);
                cmd.CommandText = query;
                cmd.Connection = con;
                if (con.State == ConnectionState.Closed)
                    con.Open();
                recordAffected= cmd.ExecuteNonQuery();

            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
            return recordAffected;

        }

       

        public Student SearchStudent(int id)
        {
            //MessageBox.Show("value" + id);
            Student student = new Student();
            try
            {
                query = "Select * from StudentService_dsingh58 Where Id="+id+"";
                //cmd.Parameters.AddWithValue("@studentId", id);
                cmd.CommandText = query;
                cmd.Connection = con;
               
                
                if (con.State == ConnectionState.Closed)
                    con.Open();
                SqlDataReader dataReader = cmd.ExecuteReader();

                          dataReader.Read();
                       student.Id = int.Parse(dataReader["Id"].ToString());
                        student.StudentName = dataReader["StudentName"].ToString();
                        student.DepartmenttCode = int.Parse(dataReader["DepartmentCode"].ToString());
                        student.StudentDob = DateTime.Parse(dataReader["StudentDob"].ToString());
                        student.StudentAddress = dataReader["StudentAddress"].ToString();

                //if (dataReader.HasRows)
                //{
                //}

            }
            catch (SqlException ex)
            {
                MessageBox.Show(" "+ex);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(" " + ex);
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
            return student;
        }

        public int UpdateStudent(Student student)
        {
            int recordAffected = 0;
            try
            {
                query = "Update StudentService_dsingh58 Set StudentName=@Name, DepartmentCode=@DeptCode, StudentDob=@StdDob, StudentAddress=@StdAddress where Id="+student.Id+"";
                cmd.Parameters.AddWithValue("@Name", student.StudentName);
                cmd.Parameters.AddWithValue("@DeptCode", student.DepartmenttCode);
                cmd.Parameters.AddWithValue("@StdDob", student.StudentDob);
                cmd.Parameters.AddWithValue("@StdAddress", student.StudentAddress);
                cmd.CommandText = query;
                cmd.Connection = con;
                if (con.State == ConnectionState.Closed)
                    con.Open();
                recordAffected = cmd.ExecuteNonQuery();

            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
            return recordAffected;
        }
    }
}
