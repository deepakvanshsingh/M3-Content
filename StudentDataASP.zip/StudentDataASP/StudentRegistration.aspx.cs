﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows;
using StudentDataASP.StudentServiceReference;

namespace StudentDataASP
{
    public partial class StudentRegistration : System.Web.UI.Page
    {
        IStudentServiceClient studentService = new IStudentServiceClient();
        Student student = new Student();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            student.StudentName = TextName.Text;
            student.DepartmenttCode = int.Parse(TextDeptCode.Text);
            student.StudentDob=DateTime.Parse(TextDob.Text);
            student.StudentAddress = TextAddress.Text;
            int status=studentService.AddStudent(student);
            if (status > 0)
                MessageBox.Show("Data Added Successfully!!","Information",MessageBoxButton.OK,MessageBoxImage.Information);
            else
            {
                MessageBox.Show("Error in adding details!!", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        protected void BtnDelete_Click(object sender, EventArgs e)
        {
            int search = int.Parse(SearchId.Text);
            if (MessageBox.Show("Are you sure you want to delete record!!", "Confirmation", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                int status = studentService.Deletetudent(search);

                if (status > 0)
                    MessageBox.Show("Data deleted Successfully!!", "Information", MessageBoxButton.OK, MessageBoxImage.Information);
                else
                {
                    MessageBox.Show("Error in adding details!!", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        protected void Button4_Click(object sender, EventArgs e)
        {

            student.Id=int.Parse(SearchId.Text);
            student.StudentName = TextName.Text;
            student.DepartmenttCode = int.Parse(TextDeptCode.Text);
            student.StudentDob = DateTime.Parse(TextDob.Text);
            student.StudentAddress = TextAddress.Text;
            int status = studentService.UpdateStudent(student);
            if (status > 0)
                MessageBox.Show("Data Updated Successfully!!", "Information", MessageBoxButton.OK, MessageBoxImage.Information);
            else
            {
                MessageBox.Show("Error in Updating details!!", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        protected void txtSearch_Click(object sender, EventArgs e)
        {
            int search = int.Parse(SearchId.Text);
          
            student =studentService.SearchStudent(search);
           
            if (student != null)
            {
                TextId.Text = student.Id.ToString();
                TextName.Text = student.StudentName;
                TextDeptCode.Text = student.DepartmenttCode.ToString();
                TextDob.Text = student.StudentDob.ToShortDateString();
                TextAddress.Text = student.StudentAddress;
            }
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            StudentDetails.DataSource= studentService.DisplayStudent();
            StudentDetails.DataBind();
        }
    }
}